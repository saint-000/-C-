/******************************************************************************************************************************************
author:saint
target:array upside down(attention:Instead of printing data in reverse order, you need to re-place the contents in the array in reverse order)
date:20020.3.27

in:a[n]={10,20,30,40,50,60,70,80}
out:a[n]={80,70,60,50,40,30,20,10}
*******************************************************************************************************************************************/

#include <stdio.h>
#define n 8
void arreverse(int *a,int b);
void arrout(int *a,int b);
main()
{
int a[n]={10,20,30,40,50,60,70,80};
arreverse(a,n);
arrout(a,n);
}

void arreverse(int *a,int b)
{
int i=0,j=b-1,t;
while(i<j)
	{
		t=a[i];
		a[i]=a[j];
		a[j]=t;
		i++;
		j--;
	}	
}

void arrout(int a[],int b)		//void arrout(int a*,int b)
{
int i;
for(i=0;i<b;i++)
printf("a[%d]=%d\n",i,a[i]);		//printf("a[%d]=%d\n",i,*(a+i));
}