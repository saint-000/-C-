/************************************************************************

target:change a row every 5 runyear
runyear1000-3000:1.divided by 4 ,can not divided by 100; 2.divided by 400

*************************************************************************/

#include <stdio.h>
main()
{
int i,k=0;
for(i=1000;i<=3000;i++)
	{
	if(i%4==0&&i%100!=0||i%400==0)//0*0:0;*00:0;110:1;**1:1;
		{
			printf("%5d",i);	//space
			k++;		//provide enter signal
		}

	if(k%5==0)
	printf("\n");
	}
}