/*************************************************************************************************************
version1

target:print 26 capital letters and their ASCII code ,at the same time,output two groups data with each row.

A 65  B 66
C 67  D 68
***************************************************************************************************************/
/*
#include <stdio.h>
main()
{
int i=65;
for(;i<=90;i++)
	{
	if(i%2!=0)
		printf("%c %d ",i,i);
	else
		{
			printf("%c %d ",i,i);
			printf("\n");
		}
	}

} 



*/
/*************************************************************************************************************
version2

target:print 26 capital letters and their ASCII code ,at the same time,output two groups data with each row.

A 65  B 66
C 67  D 68
***************************************************************************************************************/

#include <stdio.h>
main()
{
int ch,i;
for(i=0;i<=26;i++)
	{
		ch=i+65;
		if(i%2==0)
			printf("\n");
			printf("c=%c ASCII=%d ",ch,ch);
	}
					
		
} 