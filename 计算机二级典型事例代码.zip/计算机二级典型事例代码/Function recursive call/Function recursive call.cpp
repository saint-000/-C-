/**********************************************************************
author:saint
target:Function recursive call	f!:n!=n*(n-1)!	1!=1 so,0!=1
function:int f(int a)
date:2020.3.29

in:8
0ut:8!=8*7*6*5*4*3*2*1
*********************************************************************/

#include <stdio.h>
int f(int a);
main()
{
int i,j;
scanf("%d",&i);
j=f(i);
printf("%d!=%d\n",i,j);
}


int f(int a)
{
int t;
if(a==0||a==1)
return 1;		//1!=1 so,0!=1
else
	{
		t=a*f(a-1);
		return t;
	}
}
