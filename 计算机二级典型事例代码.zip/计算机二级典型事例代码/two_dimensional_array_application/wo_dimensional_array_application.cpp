/****************************************************************************************************************************************
author:saint
target:assign the integer(10-40) for the 5*6 two-dimensional array through by the random function,meanwhile print the average of each row
function:getdata()+average()+outdata()
date:2020.3.27

****************************************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#define n 5		//row
#define m 6		//column

void getdata(int (*p)[m]);
void average(int p[][m],float *a);
void outdata(int p[n][m],float a[]);

main()
{
int r[n][m];	//two-dimensional array r[][]:assign by rand()%41
float ave[n];	//one-dimensional array ave[]:5 rows ,average of 6 num
getdata(r);		//actual parameter:two-dimensional array name
average(r,ave);//actual parameter:two-dimensional array name-;one-dimensional array name
outdata(r,ave);//same as above
}

void getdata(int (*p)[m])	//formal parameter:(*p)[m] row pointer
{
int i,j,x;
for(i=0;i<n;i++)			//row
	{
		j=0;				//column initialize in case	overflow
		while(j<m)
		{
			x=rand()%41;	//random num assignment
			if(x>10)
			{
				p[i][j]=x;
				j++;		//column
			}		
		}
	}	
}

void average(int p[][m],float *a)	//formal parameter:p[][m] two-dimensional array;formal parameter:*a pointer
{
int i,j;
for(i=0;i<n;i++)			//row
	{
		float ave=0.0;		//row average initialize 
		for(j=0;j<m;j++)	//column
		ave=ave+p[i][j];
		a[i]=ave/m;			//row average store in one-dimensional array
	}

}

void outdata(int p[n][m],float a[])	//formal parameter:p[][m] two-dimensional array;formal parameter:*a pointer
{
int i,j;
printf("output the result:\n");
for(i=0;i<n;i++)					//row
	{
		for(j=0;j<m;j++)			//column
			printf("%4d",p[i][j]);	//random num
			printf(":%f\n",a[i]);	//out /row average at the end of each row
	}
printf("\n");

}