/*******************************************************************************************************************
author:saint
target:transfer_parameter is a pointer variable:	1.actual parameter use address.	2.actual parameter use pointer
function:myadd(int *a,int *b),print sum=a pluse b
date:2020.3.20
*******************************************************************************************************************/
/*version1
#include <stdio.h>
int myadd(int *a,int *b);//if formal parameter is pointer variable,Type of declaration parameter could not be omitted.
main()
{
int x,y,z;
printf("enter x,y");
scanf("%d%d",&x,&y);
z=myadd(&x,&y);			//actual parameter use address
printf("%d+%d=%d",x,y,z);

}


int myadd(int *a,int *b)
{

int sum;

sum=*a+*b;
return sum;

}
*/


//version2
#include <stdio.h>
int myadd(int *a,int *b);//if formal parameter is pointer variable,Type of declaration parameter could not be omitted.
main()
{
int x,y,z,*px,*py;
px=&x;
py=&y;
printf("enter x,y");
scanf("%d%d",&x,&y);
z=myadd(px,py);		//actual parameter use pointer
printf("%d+%d=%d",x,y,z);

}


int myadd(int *a,int *b)
{

int sum;

sum=*a+*b;
return sum;

}