/*******************************************************************************

author:saint
target:function_for-loop
date:2020.3.20

i=0,1,2
i=0,a=a+f(0)=0.0+1.0=1.0
i=1,a=a+f(1)=1.0+2.0=3.0
i=2,a=a+f(2)=3.0+2.5=5.5
out:5.500000
*******************************************************************************/

#include <stdio.h>
double f(int n)
{
int i;
double s;
s=1.0;
for(i=1;i<=n;i++)
s+=1.0/i;
return s;

}


main()
{
int i,m=3;
float a=0.0;
for(i=0;i<m;i++)
a+=f(i);
printf("%lf\n",a);

}

