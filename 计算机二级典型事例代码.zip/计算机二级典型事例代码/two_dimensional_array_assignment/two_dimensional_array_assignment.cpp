/***********************************************************************************************************
author:saint
target:two_dimensional_array_assignment,input 2*3 data
function:assignment:1.for_loop+scanf(,&a[][]).	2.pointer:int *p;p=a[j];//p=a[0]+j;	//p=&a[0][0]
date:2020.3.27

in:
1,2,3
10,20,30

out:
1,2,3
10,20,30
*********************************************************************************************************/
/*version1
#include <stdio.h>
main()
{
int a[2][3],i,j;
printf("enter data by row:\n");
for(i=0;i<2;i++)
for(j=0;j<3;j++)
scanf("%d",&a[i][j]);
printf("output a two_dimensional array:\n");
for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		printf("%4d",a[i][j]);
		printf("\n");
	}
}
*/
//version2
#include <stdio.h>
main()
{
int a[2][3],i,j=0;
int *p;
p=a[j];//p=a[0]+j;	//p=&a[0][0]
printf("enter data by row:\n");
for(i=0;i<2;i++)
	{
	for(j=0;j<3;j++)
	scanf("%d",p+3*i+j);
	}	
printf("output a two_dimensional array:\n");
for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		printf("%4d",a[i][j]);//(*(a+i))[j];	*(*(a+i)+j);	*(a[i]+j)
		printf("\n");
	}

}