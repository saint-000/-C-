/************************************************************************************************************************************
author:saint
target:Outputs the contents of a file to the screen,function feof(fp)judge end of file and return 1 mean end;else  return 0 .
function:fopen():open+fgetc():read+eof:end+fclose():close
date:2020.3.29
*************************************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
main()
{
FILE *fpout;	//*fpout:file pointer
char ch;
fpout=fopen("file_a.dat","r");	//read
ch=fgetc(fpout);				//from *fpout pointed the file_a.dat to read character
while(ch!=EOF)		//end eof
	{
		putchar(ch);
		ch=getc(fpout);
	}	
fclose(fpout);

}