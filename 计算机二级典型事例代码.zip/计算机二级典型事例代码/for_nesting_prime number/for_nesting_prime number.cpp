/*version1**************************************************************************

target:prime number from 2 to 100.
define:prime number use for define number that could only be divided by 1 or themselves.
12
234567891011

**************************************************************************************/

/*

  #include <stdio.h>
main()
{
int i,j,flag;
for(i=2;i<=100;i++)
	{	
		flag=0;		//give an initial value
		for(j=2;j<i;j++)	//inner nesting loop use the variable from outer nesting loop
		
			if(i%j==0)
			flag=1;		//testing i could be divided by a value ,then flag equal to 1 all the way
	
			if(flag==0)
			printf("%d ",i);
		
	}

}


*/

/*version 2****************************************************************************

targt:simplify the code above,reduce using  resource
idea:
No1. 2- x-1
No2. 2- x/2
No3. 2- sqrt x

***************************************************************************************/

#include <stdio.h>
#include <math.h>
main()
{
int i,j,flag;
printf("2 ");		//print 2 is a prim number because 2 is a speacial num

for(i=3;i<=100;i+=2)	//reduce the quantity of loops
	{	
		flag=0;	
		for(j=2;j<=sqrt(i)&&flag==0;j++)	//use idea No.3
		
			if(i%j==0)
			flag=1;	
	
			if(flag==0)
			printf("%d ",i);
		
	}

}