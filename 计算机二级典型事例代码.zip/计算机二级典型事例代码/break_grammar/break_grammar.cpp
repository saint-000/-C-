/*

 target:s=1+2+3+4+...+i;i>5000 print

*/


#include <stdio.h>
main()
{
int i,s;
for(i=1;;i++)	//expression 2 could not be written
	{
		s=s+i;
		if(i>5000)
		break;	//skip the loop which has the break
	}	

printf("s=%d,i=%d\n",s,i);

}