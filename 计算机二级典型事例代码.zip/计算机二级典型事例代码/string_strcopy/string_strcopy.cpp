/*
author:saint
target:string_strcopy:*b point data assign to the *a point data
function:strcopy(char *a,char *b)
date:2020.3.28

*************************************************************************/

#include <stdio.h>
void strcopy(char *a,char *b);
main()
{
char str1[20],str2[]="ABCDEFGH";
strcopy(str1,str2);
puts(str1);
}

void strcopy(char *a,char *b)
{
int i=0;
while((a[i]=b[i])!='\0')
i++;

}