/**************************************************************************************
author:saint
target:strlen:calculate the string length
function:slength(char *s)
request:formal parameter:*s Point to string header address
date:2020.3.28
***************************************************************************************/

#include <stdio.h>
int slength(char *s);
main()
{
char str[]="ABCDEF";
int len1,len2;
len1=slength(" ");
len2=slength(str);
printf("len1=%d,len2=%d\n",len1,len2);
}


int slength(char *s)
{
int n=0;
while(*(s+n)!='\0')
n++;
return n;

}
