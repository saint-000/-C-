/***********************************************************************
author:saint
target:assign array30 with odd num from 1,output 10 value each row.
function:array30_odd num assignment
date:2020.3.21

out:
a[0]=1....a[9]=19
a[10]=1....a[19]=39
a[20]=1....a[29]=59
******************************************************************************/
/*version1
#include <stdio.h>
main()
{
int a[30],i,k=1;
for(i=0;i<30;i++)
	{
		a[i]=k;
		k+=2;
		printf("a[%d]=%d  ",i,a[i]);
	
		if(i==9||i==19||i==29)	//(i+1)%10==0
		printf("\n");
	}

}

*/
/******************************************************************************
/*version2

#include <stdio.h>
main()
{
int a[30],i,k=1;

for(i=0;i<30;i++)
	{
		a[i]=k;
		k+=2;
	}
for(i=0;i<30;i++)
		{
			printf("a[%d]=%d  ",i,a[i]);
			if(i==9||i==19||i==29)
			printf("\n");	
		}

}

 ******************************************************************************/

#include <stdio.h>
#define m 30
main()
{
int a[m],i,k=1;
for(i=0;i<m;i++)
	{
		a[i]=k;
		k+=2;
	}
for(i=0;i<m;i++)
		{		
			printf("a[%d]=%d  ",i,a[i]);
			if((i+1)%10==0)	//(i+1)%10==0
			printf("\n");	
		}
	

}
