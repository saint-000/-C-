/**************************************************************************
author:saint
target:read_file from path:file_c.dat and print 
function:fopen(" "," ")+feof(fp)+fgetc(fp)+putchar(ch)+fclose(fp)
date:2020.3.30
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
main()
{
FILE *fp;
char ch;
fp=fopen("file_c.dat","r");
ch=fgetc(fp);
while(!feof(fp))
	{
		putchar(ch);
		ch=fgetc(fp);
	}
printf("\n");
fclose(fp);
}


