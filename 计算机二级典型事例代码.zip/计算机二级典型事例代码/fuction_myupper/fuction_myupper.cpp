/*********************************************************************************
author:saint
target:fuction_myupper(ch):change the  lower-case letter to upper case letter
in:aBCd
out:ABCD
date:2020.3.19
*********************************************************************************/

#include <stdio.h>
char myupper(char);

main()
{

char c;
while((c=getchar())!='\@')	//priority level:      "!=" higher than "="         (judgement>evaluation)
	{
		c=myupper(c);
		putchar(c);
	}


}

char myupper(char ch)
{

if(ch>='a'&&ch<='z')
ch=ch-32;
return ch;

}
