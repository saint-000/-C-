/*******************************************************************************************
author:saint
target:transfer the input data to file_b.dat,use @ to be the signal of the end 
progress:
1.open file	2.input a char	3.judge the char whether is @.yes,stop loop and run step 7
4.print the char to the aim file	5.input char	6.repet 3,5		7. close file	 
date:2020.3.29
*********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
main()
{
FILE *fpout;
char ch;

if((fpout=fopen("file_b.dat","w"))==NULL)
	{
		printf("can not open this file!\n");
		exit(0);		//quit
	}
	
		while((ch=getchar())!='@')
			{
				fputc(ch,fpout);
			}	
				fclose(fpout);
}