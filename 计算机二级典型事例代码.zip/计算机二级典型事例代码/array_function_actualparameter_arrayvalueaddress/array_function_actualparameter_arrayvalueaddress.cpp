/**********************************************************************
author:saint
target:array_function_actualparameter_array value address
function:10char change from c[4] for *,Others remain unchanged
date:2020.3.24

in:c[10]={'A','B','C','D','E','F','G','H','I','J','K'}
out:c[10]={'A','B','C','D','*','*','*','*','*','*','*'}

************************************************************************/

#include <stdio.h>
#define m 10
#define n 4
void setstar(char *p,int o);
void arrout(char *a,int q);
main()
{
	char c[m]={'A','B','C','D','E','F','G','H','I','J'};
	setstar(&c[n],m-n);	//actualparameter_array value address
	arrout(&c[0],m);//actualparameter_array name=first address		arrout(c,m);
}

void setstar(char *p,int o)
{
int i;
for(i=0;i<o;i++)
*(p+i)='*';
}

void arrout(char *a,int q)
{
int i;
for(i=0;i<q;i++)
printf("%c",*(a+i));
printf("\n");
}