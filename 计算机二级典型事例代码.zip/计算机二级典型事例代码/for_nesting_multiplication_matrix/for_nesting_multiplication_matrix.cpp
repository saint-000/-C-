#include <stdio.h>
main()
{
int i,j;
for(i=1;i<10;i++)
	{
		for(j=1;j<10;j++)
			printf("%d*%d=%2d ",i,j,i*j);	//each multiplicational eaual need a space,%2d use for center alignment  
			printf("\n");
	}

}
