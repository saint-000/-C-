/*************************************************************************************************************
auhtor:saint
target:
write a programmar ,define an array has been included 15 elments,finishing the function below:
1.random function was called to assign the random num (0-49) to all elments.
2.output the elment of array.
3.Find a sum of every three numbers in order and return the main function
4.outout the sum
function:<stdlib.h>+rand()
date:2020.3.27

a[0-14]:0~49
*************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#define n 15
#define m 3
void getvalue(int *a,int b);
void getsumvalue(int *a,int *b,int c);

main()
{
int x[n],y[n/m]={0};
printf("output%d random number:\n\n",n);
getvalue(x,n);
printf("\n");
printf("output%d sum each three elments:\n\n",n);
getsumvalue(x,y,n);
}

void getvalue(int *a,int b)
{
int i;
for(i=0;i<b;i++)
	{
		*(a+i)=rand()%50;		//rand()% :random function
		if(i%3==0&&i!=0)
		printf("\n");
		printf("a[%2d]=%2d ",i,*(a+i));
	}
printf("\n");
}


void getsumvalue(int *a,int *b,int c)
{
int z,sum=0,x=0;
for(z=0;z<c;z++)
	{
		sum+=*(a+z);	//sum+=a[z];
		if((z+1)%m==0)
			{
				*(b+x)=sum;		//b[x]=sum;
				sum=0;
				printf("b[%2d]=%2d ",x,*(b+x));	//printf("b[%2d]=%2d ",x,b[x]);
				x++;
			}	

	}
printf("\n");
}

