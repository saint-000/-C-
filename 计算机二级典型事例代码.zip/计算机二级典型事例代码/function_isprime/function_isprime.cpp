/*


target:function_isprime judge whether a is prime,if yes fuction return 1,otherwise return 0.
in:11	12
out:1	0

*/

#include <stdio.h>
int isprime(int);
main()
{
int x;
printf("please enter a random number: ");
scanf("%d",&x);
	if (isprime(x))
	printf("%d is prime\n",x);
	else 
	printf("%d is not prime\n",x);

}


int isprime(int a)
{
	int i=2;
	for(;i<=a-1;i++)
		
		if(a%i==0)
		return 0;
		return 1;


}