/****************************************************************************************

target:s<5 print:s;s>5 print:s=
grammar:continue:skip the sentence that next to the continue and return the start of loop 

*****************************************************************************************/

#include <stdio.h>
main()
{

int i=1,s=0;
for(;i<=5;i++)
	{
		s+=i;
		if(s>5)
		{
			printf("s=%d\n",s);
			continue;
		}

		printf("%d\n",s);

	}

}