/************************************************************************************************************************************

author:saint
target:pointer_address formal parameter:formal parameter(pointer) impact actual parameter:1.return 2.use address to call function.
function:change a and b
date:2020.3.21

in 2 3
out:3 2
************************************************************************************************************************************/

#include <stdio.h>
void chang(int *,int *);	//non-return
main()
{

int x,y;
scanf("%d%d",&x,&y);
printf("x=%d,y=%d\n",x,y);	//1

chang(&x,&y);
printf("x=%d,y=%d\n",x,y);	//4
}

void chang(int *a,int *b)
{

int t;
printf("x=%d,y=%d\n",*a,*b);	//2
t=*a;
*a=*b;
*b=t;
printf("x=%d,y=%d\n",*a,*b);	//3

}

