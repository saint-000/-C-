/**********************************

target:capital letters pyramid
in:row number=3
out:		  A
			 BBB
			CCCCC
	   	   
 ********************************/

#include <stdio.h>
main()
{
	
while(1)
	{
int a,i,j,k;
//int ch=65;
char ch='A';
printf("please enter an integer=");
scanf("%d",&a);

for(i=1;i<=a;i++)		//row
		{
	for(k=a;k>i;k--)	//space	
		printf(" ");	
	
	for(j=1;j<=i*2-1;j++)	//character num
			{
			//printf("%c",ch);
			putchar(ch);
			
			}
		
	ch++;
	printf("\n");
	
		}	
	
	}
}



