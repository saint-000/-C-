/***********************************************************************
author:saint
target:fucntion_count_ch:count the number of character ,end up with @
date:2020.3.19

in:ab c
out:4
*************************************************************************/
/*version1
#include <stdio.h>
countch();
main()
{
long n;
n=countch();
printf("n=%ld",n);

}
 
countch()
{
long i;
for(i=0;getchar()!='@';i++)
;
return i;
}
*/

//version2
#include <stdio.h>
countch();
main()
{
long n;
n=countch();
printf("n=%ld",n);

}
 
countch()
{
long i,j=0;
while((i=getchar())!='@')
j++;
return j;
}