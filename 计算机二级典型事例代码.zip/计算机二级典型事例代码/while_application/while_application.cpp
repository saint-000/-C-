/***********************************************************************************************************************

target:select the maxium value from the input which has lots of positive integer greater than zero,use -1 to stop 
grammar:while,do while,scanf,printf,if,

1 2 3 4 5      5


***********************************************************************************************************************/


#include <stdio.h>
main()

{
int x,max;
do 
	{

printf("enter x:");
scanf("%d",&x);			//do not omit,otherwise deep in loop due to initial value is null

	}while(x<0&&x!=-1);	
max=x;	//because xmax=-1

while(x!=-1)
		{		
printf("enter x:");
scanf("%d",&x);
if(x>max)
max=x;
		}
printf("max=%d",max);

		
}