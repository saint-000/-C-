/*******************************************************************************************
author:saint
target:function_pointer,calculate the tan and cotan
function:double tran(double(*f1)(double),double(*f2)(double),double x)
date:2020.3.29
******************************************************************************************/

#include <stdio.h>
#include <math.h>
#define m 45

double tran(double(*f1)(double),double(*f2)(double),double x);
main()
{
double y,v;
v=m*3.1416/180.0;		//pi/3
y=tran(sin,cos,v);		//actual parameter:double type sin()\double type cos()\double type v:calculate the tan
printf("tan(%d)=%lf\n",m,y);
y=tran(cos,sin,v);		//actual parameter:double type cos()\double type sin()\double type v:calculate the cotan
printf("cot(%d)=%lf\n",m,y);
}

double tran(double(*f1)(double),double(*f2)(double),double x)	//function_pointer:*f1��*f2
{
return (*f1)(x)/(*f2)(x);
}