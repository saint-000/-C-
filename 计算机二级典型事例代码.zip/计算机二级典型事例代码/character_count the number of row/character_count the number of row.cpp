/*******************************************************

target:character_count the number of row,use ! to end up.

in:
	1
	2
	3
	
	5
	!
out:5

**********************************************************/

#include <stdio.h>
main()
{
int i=0;
char ch;
while(ch!='\!')
	{
		ch=getchar();
		if(ch=='\n')
		i++;

	}

printf("%d",i);


}