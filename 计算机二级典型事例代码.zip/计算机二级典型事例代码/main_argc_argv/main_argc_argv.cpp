/*****************************************************************************************
author:saint
target:argc:print the num of string (include the name of file) argv:print the string 
function:main(int ,char**)	//main(int ,char*p[])
date:2020.3.28
path:D:\code_MLW\main_argc_argv\Debug\main_argc_argv

testway:1.win+R	2.cmd	3.D:\code_MLW\main_argc_argv\Debug\main_argc_argv	4.in:hello	5.out:argc=2,hello		
******************************************************************************************/

#include <stdio.h>
main(int argc,char *argv[])
{
int i;
printf("argc=%d\n",argc);
for(i=1;i<argc;i++)
printf("%s",argv[i]);
printf("\n");
}