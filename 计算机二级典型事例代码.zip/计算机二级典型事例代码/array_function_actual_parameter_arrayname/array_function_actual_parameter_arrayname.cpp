/**************************************************************************************
author:saint
target:array_function_actual_parameter_arrayname
function:arrin:input some integer >=0 in array;use negative to stop;arrout:print
date:2020.3.24
**************************************************************************************/
/*version1
#include <stdio.h>
int arrin(int *);
void arrout(int *,int );
main()
{
int a[10],k;
k=arrin(a);
arrout(a,k);
}

int arrin(int *p)
{
int i=0;
for(;i<10;i++)
	{
		scanf("%d",p+i);
		if(*(p+i)<0)
		break;	
		else 
		continue;
	}
return i  ;
}

void arrout(int *o,int k)
{
int i=0;
for(;i<k;i++)
printf("a[%d]=%d\n",i,*(o+i));
}

*/
//version2
#include <stdio.h>
#define m 5
int arrin(int *);
void arrout(int *,int );
main()
{
int a[m],k;
k=arrin(a);
arrout(a,k);
}

int arrin(int *p)
{
int i=0,x;
scanf("%d",&x);
while(x>=0&&i<m)
	{
		*(p+i)=x;
		i++;
		scanf("%d",&x);		//add this code to break the loop
		
	}
return i;		//i=5
}

void arrout(int *o,int k)
{
int i=0;
for(;i<k;i++)
	{
	printf(((i+1)%5==0)?"a[%d]=%d ":"a[%d]=%d\n",i,*(o+i));			//judgement code:a?b:c	a is true run b/b is true run c	
																																					
																					//way2
	}																				//	if((i+1)%5!=0)
	printf("\n");																	//	printf("a[%d]=%d ",i,*(o+i));
}																					//	else
																					//	printf("a[%d]=%d\n",i,*(o+i));