/******************************************************************************************
author:saint
target:array_Input assignment
function:pointer should move+printf(a[i]),instead of printf(*p).because *p stable value
date:2020.3.21

******************************************************************************************/

#include <stdio.h>
main()
{
int a[10],i,*p;
p=a;
for(i=0;i<10;i++)
//scanf("%d",&a[i]);	if do that,array a could not accapt the imput value except the a[0],due to the  &a[i] is acquire the first address
//scanf("%d",a);either can not,	due to the  &a[i] is acquire the first address
	
scanf("%d",p++);	//pointer should move
for(i=0;i<10;i++)
printf("a[%d]=%d\n",i,a[i]);	
	

}
