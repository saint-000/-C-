/***************************************

target:character_number change integer

in	2  4  8  3
out		2483

****************************************/

#include <stdio.h>
main()
{
	int i=0;
	char ch;
	do	
	{
		ch=getchar();
		if(ch>='0'&&ch<='9')
			{	
				i=i*10+ch-'0';
				
			}
	}while(ch!='\n');


printf("%d",i);

}