/**************************************************************
author:saint
target:guiding principle+compare the small num
date:2020.3.20
**************************************************************/

#include <stdio.h>
main()
{
int a,b,min,*pa,*pb,*pmin;
pa=&a;	//give guiding principle an address
pb=&b;	//give guiding principle an address
pmin=&min;	//give guiding principle an address
scanf("%d%d",pa,pb);	//Address

*pmin=*pa;
if(*pmin>*pb)
*pmin=*pb;

printf("%d",*pmin);


}