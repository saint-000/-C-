/******************************************************************************************************************************************

author:saint
target:Write a program so that the first argument in the function always holds smaller numbers and the second argument holds larger numbers
function:order()+change()formal parameter is pointer
date:2020.3.21

*******************************************************************************************************************************************/

#include <stdio.h>
void order(int *x,int *y);
void change(int *i,int *j);
main()
{

int a,b;
printf("enter a,b=");
scanf("%d%d",&a,&b);
order(&a,&b);

}

void order(int *x,int *y)
{
if(*x<*y)
change(x,y);	//non-*:transfer address;	*:transfer address value
}

void change(int *i,int *j)
{
int t;
t=*i;
*i=*j;
*j=t;
printf("a=%d,b=%d",*i,*j);
}
