#include <stdio.h>
main()
{
int i,j,k;
for(i=0;i<=3;i++)	//control row
	{

for(j=1;j<=i;j++)	//control space
	printf(" ");
		

for(k=0;k<7-2*i;k++)	//control star
printf("*");	

printf("\n");

	}
}